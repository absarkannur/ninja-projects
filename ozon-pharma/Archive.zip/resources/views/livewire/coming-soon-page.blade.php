<main>

    <style>

        html, body {
            position: relative;
            height: 100vh;
            width: 100%;
        }

        .topbar-wrapper,
        .navbar,
        footer{
            display: none !important;
        }

        .comingsoon{
            display: block;
            width: 320px;
            height: 100px;
            line-height: 100px;
            position: absolute;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            margin: auto;
            text-align: center;
        }

    </style>

    <h1 class="comingsoon">COMING SOON</h1>

</main>
