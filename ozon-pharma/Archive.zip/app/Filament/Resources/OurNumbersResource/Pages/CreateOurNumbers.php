<?php

namespace App\Filament\Resources\OurNumbersResource\Pages;

use App\Filament\Resources\OurNumbersResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOurNumbers extends CreateRecord
{
    protected static string $resource = OurNumbersResource::class;
}
