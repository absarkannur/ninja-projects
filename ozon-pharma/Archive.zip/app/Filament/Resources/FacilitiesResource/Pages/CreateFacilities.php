<?php

namespace App\Filament\Resources\FacilitiesResource\Pages;

use App\Filament\Resources\FacilitiesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFacilities extends CreateRecord
{
    protected static string $resource = FacilitiesResource::class;
}
