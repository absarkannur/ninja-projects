<?php

namespace App\Filament\Resources\FacilitiesCategoryResource\Pages;

use App\Filament\Resources\FacilitiesCategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFacilitiesCategory extends CreateRecord
{
    protected static string $resource = FacilitiesCategoryResource::class;
}
