<?php

namespace App\Livewire;

use Livewire\Component;

class StrategyPage extends Component
{
    public function render()
    {
        return view('livewire.strategy-page');
    }
}
