<?php

namespace App\Livewire;

use Livewire\Component;

class ComingSoonPage extends Component
{
    public function render()
    {
        return view('livewire.coming-soon-page');
    }
}
