<?php

namespace App\Livewire;

use Livewire\Component;

class PharmacovigilancePage extends Component
{
    public function render()
    {
        return view('livewire.pharmacovigilance-page');
    }
}
