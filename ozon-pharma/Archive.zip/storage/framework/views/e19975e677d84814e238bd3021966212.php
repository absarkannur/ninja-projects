<main>

    <?php if (isset($component)) { $__componentOriginal985c30fd01c97bfac8dc888213994c24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal985c30fd01c97bfac8dc888213994c24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.widgets.banner','data' => ['title' => 'Products','breadcrumbs' => '<a href=\'/\'>Home</a> > Products','image' => 'ozon/images/products-banner.png']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('widgets.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Products','breadcrumbs' => '<a href=\'/\'>Home</a> > Products','image' => 'ozon/images/products-banner.png']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal985c30fd01c97bfac8dc888213994c24)): ?>
<?php $attributes = $__attributesOriginal985c30fd01c97bfac8dc888213994c24; ?>
<?php unset($__attributesOriginal985c30fd01c97bfac8dc888213994c24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal985c30fd01c97bfac8dc888213994c24)): ?>
<?php $component = $__componentOriginal985c30fd01c97bfac8dc888213994c24; ?>
<?php unset($__componentOriginal985c30fd01c97bfac8dc888213994c24); ?>
<?php endif; ?>

    <section class="product-search-container">
        <div class="container">
            <div class="row">
                <div class="col">
                    <ul class="form-options">
                        <li class="option header"><em>Search By</em></li>
                        <li class="option">
                            <input wire:model.live="filter" type="radio" id="search_product_name" name="search_filter" value="Product Name">
                            <label for="search_product_name">Product Name</label>
                        </li>
                        <li class="option">
                            <input wire:model.live="filter" type="radio" id="search_therapeutic" name="search_filter" value="Therapeutic Categories">
                            <label for="search_therapeutic">Therapeutic Categories</label>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-inputs">

                        <!--[if BLOCK]><![endif]--><?php if( $filter === 'Product Name' ): ?>

                            <form wire:submit="submit">
                                <div class="row">
                                    <div class="col-9 col-md-10 col-lg-10 col-xl-10">
                                        <input wire:model.live="search" type="text" placeholder="Search Products ...">
                                    </div>
                                    <div class="col-3 col-md-2 col-lg-2 col-xl-2">
                                        <div class="button-group">
                                            <button type="submit" class="oz-mo oz-button-primery p-l-10 center">
                                                Search
                                            </button>
                                            <button type="submit" class="oz-button-primery no-padding p-l-10 center">
                                                <svg xmlns="http://www.w3.org/2000/svg" style="transform: rotate(-45deg);" width="30" height="30" fill="currentColor" class="bi bi-arrow-right-short" viewBox="0 0 16 16">
                                                    <path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8"></path>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>

                        <?php else: ?>
                            <form wire:submit="submit">
                                <div class="row">
                                    <div class="col-9 col-md-10 col-lg-10 col-xl-10">
                                        <select wire:model.live="categories">
                                            <option value="" disabled>Select Categories</option>

                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $therapeutic_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($categories->therapeutic_category_slug); ?>"><?php echo e($categories->therapeutic_category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                                        </select>
                                    </div>
                                    <div class="col-3 col-2 col-lg-2 col-xl-2">
                                        <div class="button-group">
                                            <button class="oz-mo oz-button-primery p-l-10 center">
                                                Search
                                            </button>
                                            <button type="submit" class="oz-button-primery no-padding p-l-10 center">
                                                <svg xmlns="http://www.w3.org/2000/svg" style="transform: rotate(-45deg);" width="30" height="30" fill="currentColor" class="bi bi-arrow-right-short" viewBox="0 0 16 16">
                                                    <path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8"></path>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="products-container">
        <div class="container"> 
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">

                    <ul class="products-list">

                        <!--[if BLOCK]><![endif]--><?php if( $products != null ): ?>

                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="product">

                                    <div class="image-wrap">
                                        <div class="imagethmb">
                                            <div class="imagethmb_inner">
                                                <img src="<?php echo e(asset("storage/" . $product->product_image )); ?>" alt="">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="content-wrap">
                                        <h3><?php echo e($product['product_name']); ?></h3>
                                        <p><?php echo e($product['product_description']); ?></p>
                                        <button class="oz-button-primery">Product Details</button>
                                    </div>

                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                        <?php else: ?>

                            <h3>No Result</h3>

                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    </ul>

                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!--[if BLOCK]><![endif]--><?php if( $products != null ): ?>
                    <?php echo e($products->links()); ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

    </section>


</main>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/ozon-pharma/resources/views/livewire/products-page.blade.php ENDPATH**/ ?>