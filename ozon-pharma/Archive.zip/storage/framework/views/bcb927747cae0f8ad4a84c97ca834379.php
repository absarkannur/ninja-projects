<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo e($title ?? 'OZON Pharmaceuticals'); ?></title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

        <link rel="stylesheet" href="<?php echo e(asset('ozon/css/bootstrap.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('ozon/css/owl.carousel.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('ozon/css/owl.theme.default.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('ozon/css/tiptap-custom.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('ozon/css/init.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('ozon/css/styles.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('ozon/css/inner-styles.css')); ?>" />

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


    </head>
    <body>

        <?php if (isset($component)) { $__componentOriginalb2351034fff8febe50a5c7b632e22b79 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2351034fff8febe50a5c7b632e22b79 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header.topbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2351034fff8febe50a5c7b632e22b79)): ?>
<?php $attributes = $__attributesOriginalb2351034fff8febe50a5c7b632e22b79; ?>
<?php unset($__attributesOriginalb2351034fff8febe50a5c7b632e22b79); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2351034fff8febe50a5c7b632e22b79)): ?>
<?php $component = $__componentOriginalb2351034fff8febe50a5c7b632e22b79; ?>
<?php unset($__componentOriginalb2351034fff8febe50a5c7b632e22b79); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal31957d141ae861b1f5561ff93907165b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal31957d141ae861b1f5561ff93907165b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal31957d141ae861b1f5561ff93907165b)): ?>
<?php $attributes = $__attributesOriginal31957d141ae861b1f5561ff93907165b; ?>
<?php unset($__attributesOriginal31957d141ae861b1f5561ff93907165b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31957d141ae861b1f5561ff93907165b)): ?>
<?php $component = $__componentOriginal31957d141ae861b1f5561ff93907165b; ?>
<?php unset($__componentOriginal31957d141ae861b1f5561ff93907165b); ?>
<?php endif; ?>

        <?php echo e($slot); ?>


        <?php if (isset($component)) { $__componentOriginalf616a8f3c572fc16e4336d6c64a747a8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf616a8f3c572fc16e4336d6c64a747a8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf616a8f3c572fc16e4336d6c64a747a8)): ?>
<?php $attributes = $__attributesOriginalf616a8f3c572fc16e4336d6c64a747a8; ?>
<?php unset($__attributesOriginalf616a8f3c572fc16e4336d6c64a747a8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf616a8f3c572fc16e4336d6c64a747a8)): ?>
<?php $component = $__componentOriginalf616a8f3c572fc16e4336d6c64a747a8; ?>
<?php unset($__componentOriginalf616a8f3c572fc16e4336d6c64a747a8); ?>
<?php endif; ?>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src=<?php echo e(asset('ozon/js/owl.carousel.min.js')); ?>></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        <script src=<?php echo e(asset( 'ozon/js/script.js' )); ?>></script>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    </body>
</html>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/ozon-pharma/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>