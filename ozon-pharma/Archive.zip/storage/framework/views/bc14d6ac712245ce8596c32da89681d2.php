<main>

    <?php if (isset($component)) { $__componentOriginal985c30fd01c97bfac8dc888213994c24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal985c30fd01c97bfac8dc888213994c24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.widgets.banner','data' => ['title' => 'Facilities','breadcrumbs' => '<a href=\'/\'>Home</a> > Facilities','image' => 'ozon/images/facilities.png']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('widgets.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Facilities','breadcrumbs' => '<a href=\'/\'>Home</a> > Facilities','image' => 'ozon/images/facilities.png']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal985c30fd01c97bfac8dc888213994c24)): ?>
<?php $attributes = $__attributesOriginal985c30fd01c97bfac8dc888213994c24; ?>
<?php unset($__attributesOriginal985c30fd01c97bfac8dc888213994c24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal985c30fd01c97bfac8dc888213994c24)): ?>
<?php $component = $__componentOriginal985c30fd01c97bfac8dc888213994c24; ?>
<?php unset($__componentOriginal985c30fd01c97bfac8dc888213994c24); ?>
<?php endif; ?>

    <section class="facilities-page-wrapper">
        <div class="container"> 
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <h2 class="heading">OUR FACILITIES</h2>
                </div>
            </div>
        </div>

        <div class="container">
            <dic class="row">
                <div class="col">

                    <ul class="facilities-list">

                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $facilities_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list">
                                <a href=<?php echo e('facility/' . $category->facility_category_slug); ?>>
                                    <div class="image-wrap" style="background-image: url('<?php echo e(asset( "storage/" . $category->facility_category_image )); ?>')"></div>
                                    <div class="content-wrap">
                                        <h4><?php echo e($category->facility_category_name); ?></h4>
                                        <p><?php echo e($category->facility_category_description); ?></p>
                                    </div>

                                    <svg class="left-sticky-corner" width="111" height="111" viewBox="0 0 111 111" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 0C19.33 0 35 15.67 35 35V41C35 60.33 50.67 76 70 76H76C95.33 76 111 91.67 111 111V0H0Z" fill="white"/>
                                    </svg>

                                    <span class="button">
                                        <svg xmlns="http://www.w3.org/2000/svg" style="transform: rotate(-45deg);" width="45" height="45" fill="currentColor" class="bi bi-arrow-right-short" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8"></path>
                                        </svg>
                                    </span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                    </ul>

                </div>
            </dic>
        </div>

    </section>

</main>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/ozon-pharma/resources/views/livewire/facilities-page.blade.php ENDPATH**/ ?>