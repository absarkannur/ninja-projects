<main>

    <?php if (isset($component)) { $__componentOriginalf3e4de21508727a49bbcf0a972e76d7d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf3e4de21508727a49bbcf0a972e76d7d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.widgets.blog-banner','data' => ['title' => ''.e($articles->title).'','breadcrumbs' => '<a href=\'/\'>Home</a> > <a href=\'/articles\'>News</a>','image' => ''.e(asset( 'storage/' . $articles->thumbnail )).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('widgets.blog-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($articles->title).'','breadcrumbs' => '<a href=\'/\'>Home</a> > <a href=\'/articles\'>News</a>','image' => ''.e(asset( 'storage/' . $articles->thumbnail )).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf3e4de21508727a49bbcf0a972e76d7d)): ?>
<?php $attributes = $__attributesOriginalf3e4de21508727a49bbcf0a972e76d7d; ?>
<?php unset($__attributesOriginalf3e4de21508727a49bbcf0a972e76d7d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3e4de21508727a49bbcf0a972e76d7d)): ?>
<?php $component = $__componentOriginalf3e4de21508727a49bbcf0a972e76d7d; ?>
<?php unset($__componentOriginalf3e4de21508727a49bbcf0a972e76d7d); ?>
<?php endif; ?>

    <section class="inner-news-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="tip__tap">
                        <?php echo tiptap_converter()->asHTML($articles->content); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>

</main>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/ozon-pharma/resources/views/livewire/article-page.blade.php ENDPATH**/ ?>