<section class="home-contact-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <h2>Contact Us</h2>

                <ul class="address">
                    <li>
                        <svg width="30" height="30">
                            <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#building-2-shape')); ?>></use>
                        </svg>
                        <span class="text">4WA Building</span>
                    </li>
                    <li>
                        <svg width="30" height="30">
                            <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#phone-shape')); ?>></use>
                        </svg>
                        <span class="text">+971 55 335 1001</span>
                    </li>
                    <li>
                        <svg width="30" height="30">
                            <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#envelope-shape')); ?>></use>
                        </svg>
                        <span class="text">info@favtech.ae</span>
                    </li>
                    <li>
                        <svg width="30" height="30">
                            <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#map-pin-thick-shape')); ?>></use>
                        </svg>
                        <span class="text">G25 Dubai Airport Freezone ,Dubai , UAE</span>
                    </li>
                </ul>

            </div>
            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <?php if (isset($component)) { $__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact-form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207)): ?>
<?php $attributes = $__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207; ?>
<?php unset($__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207)): ?>
<?php $component = $__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207; ?>
<?php unset($__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</section><?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/livewire/contact.blade.php ENDPATH**/ ?>