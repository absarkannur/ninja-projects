<div>
    <h1>Hello</h1>
</div><?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/components/layouts/middleware.blade.php ENDPATH**/ ?>