<div>
    <!--[if BLOCK]><![endif]--><?php if($paginator->hasPages()): ?>
        <nav role="navigation" aria-label="Pagination Navigation">
            <span>
                <!--[if BLOCK]><![endif]--><?php if($paginator->onFirstPage()): ?>
                    <span>Previous</span>
                <?php else: ?>
                    <button wire:click="previousPage" wire:loading.attr="disabled" rel="prev">Previous</button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </span>
 
            <span>
                <!--[if BLOCK]><![endif]--><?php if($paginator->onLastPage()): ?>
                    <span>Next</span>
                <?php else: ?>
                    <button wire:click="nextPage" wire:loading.attr="disabled" rel="next">Next</button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </span>
        </nav>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/vendor/livewire/pagination.blade.php ENDPATH**/ ?>