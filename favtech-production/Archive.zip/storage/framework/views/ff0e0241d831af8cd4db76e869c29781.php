<section>
    
    <section class="container-banner">
        <div class="owl-carousel owl-theme banner_slider">
            <!--[if BLOCK]><![endif]--><?php if( $banners ): ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="title">
                        <h1><?php echo e($banner['banner_title']); ?></h1>
                        <h6><?php echo e($banner['banner_subtitle']); ?></h6>
                    </div>
                    <img src=<?php echo e(asset( 'storage/'. $banner['banner_image'] )); ?> alt="" />
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </section>

    <section class="home-info-wrapper">
        <div class="container-fluid">
            <div class="row justify-content-md-center">
                <div class="col-12 col-sm-12 col-md-8 col-lg-8 col-xl-8">
                    <ul class="info-list">
                        <li class="list">
                            <div class="wrap">
                                <svg width="50" height="50">
                                    <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#car_clock-thick')); ?>></use>
                                </svg>
                                <div>
                                    <span class="title">Fast Delivery</span>
                                    <span class="sub-title">Same day shipping</span>
                                </div>
                            </div>
                        </li>
                        <li class="list">
                            <div class="wrap">
                                <svg width="50" height="50">
                                    <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#worker-thick')); ?>></use>
                                </svg>
                                <div>
                                    <span class="title">Professional team</span>
                                    <span class="sub-title">Multilingual communication</span>
                                </div>
                            </div>
                        </li>
                        <li class="list">
                            <div class="wrap">
                                <svg width="40" height="40">
                                    <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#shield-checkmark-shape')); ?>></use>
                                </svg>
                                <div>
                                    <span class="title">Secure Shopping</span>
                                    <span class="sub-title">Best security features</span>
                                </div>
                            </div>
                        </li>
                        <li class="list">
                            <div class="wrap">
                                <svg width="40" height="40">
                                    <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#layers-shape')); ?>></use>
                                </svg>
                                <div>
                                    <span class="title">Unlimited Stocks</span>
                                    <span class="sub-title">Always physical stocks</span>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    
    <section class="home-products-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <h2 class="header">LATEST PRODUCTS</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <ul class="owl-carousel owl-theme product-list home_product_list">

                        <!--[if BLOCK]><![endif]--><?php if( $products ): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-item">
                                <div class="image-wrapper">
                                    <div class="imagethmb">
                                        <div class="imagethmb_inner">
                                            <img src=<?php echo e(asset( 'storage/' . $product['product_image'] )); ?> alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="details-wrapper">
                                    <div class="product_name">
                                        <span class="tag"><?php echo e($product['product_name']); ?></span>
                                        <span class="title"><?php echo e($product['product_name']); ?>+<?php echo e($product['product_model']); ?>+<?php echo e($product['product_part_number']); ?></span>
                                    </div>
                                    <div class="product_enquiry">
                                        <a class="whatsapp" target="__blank" href="<?php echo e('https://wa.me/+971553351001/?text=I am interested with ' .  $product['product_model']. '-' . $product['product_part_number']); ?>">
                                            <svg width="24" height="24">
                                                <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#whatsapp-filled')); ?>></use>
                                            </svg>
                                            Quick Enquiry
                                        </a>
                                    </div>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="home-info-block-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <p>100% BRAND NEW, ORIGINAL SPARE PARTS WHOLESALE SUPPLIER</p>
                </div>
            </div>
        </div>
    </section>

    <section class="home-brands-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <h2>Our trusted partners</h2>
                    <p>Favtech FZCO is specialized in dealing with genuine spare parts for mobile phones , such as SERVICE PACK LCD for all Brands</p>
                </div>
                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">

                    <!--[if BLOCK]><![endif]--><?php if( $brands ): ?>
                    <ul class="brands-list">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list">
                            <div class="imagethmb">
                                <div class="imagethmb_inner">
                                    <img src=<?php echo e(asset( 'storage/' . $brand['brand_image'] )); ?> alt="" />
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                </div>
            </div>
        </div>
    </section>

    <section class="home-faq-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="faq_wrap">

                        <h3>Some Important FAQ's</h3>
                        <h2>Common Frequently Asked Questions</h2>

                        <div class="accordion faq_accordion" id="faq_accordion">

                            <!--[if BLOCK]><![endif]--><?php if( $faq ): ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button <?php echo e(( $key === 0 ) ? '' : 'collapsed'); ?>" type="button" data-bs-toggle="collapse" data-bs-target=<?php echo e('#collapseOne_' . $key); ?> aria-expanded="false" aria-controls=<?php echo e('collapseOne_' . $key); ?>>
                                            Q: <?php echo e($fq->faq_question); ?>

                                        </button>
                                    </h2>
                                    <div id=<?php echo e('collapseOne_' . $key); ?> class="accordion-collapse collapse <?php echo e(( $key === 0 ) ? 'show' : ''); ?>" data-bs-parent="#faq_accordion">
                                        <div class="accordion-body">
                                            <?php echo e($fq->faq_answer); ?>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="image_wrapper">
                        <img src=<?php echo e(asset( 'fav/images/faq.png' )); ?> alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="home-contact-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <h2>Contact Us</h2>
                    <ul class="address">
                        <li>
                            <svg width="30" height="30">
                                <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#building-2-shape')); ?>></use>
                            </svg>
                            <span class="text">4WA Building</span>
                        </li>
                        <li>
                            <svg width="30" height="30">
                                <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#phone-shape')); ?>></use>
                            </svg>
                            <span class="text">+971 55 335 1001</span>
                        </li>
                        <li>
                            <svg width="30" height="30">
                                <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#envelope-shape')); ?>></use>
                            </svg>
                            <span class="text">info@favtech.ae</span>
                        </li>
                        <li>
                            <svg width="30" height="30">
                                <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#map-pin-thick-shape')); ?>></use>
                            </svg>
                            <span class="text">G25 Dubai Airport Freezone ,Dubai , UAE</span>
                        </li>
                    </ul>

                </div>
                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <?php if (isset($component)) { $__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact-form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207)): ?>
<?php $attributes = $__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207; ?>
<?php unset($__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207)): ?>
<?php $component = $__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207; ?>
<?php unset($__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </section>

</section>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/livewire/home.blade.php ENDPATH**/ ?>