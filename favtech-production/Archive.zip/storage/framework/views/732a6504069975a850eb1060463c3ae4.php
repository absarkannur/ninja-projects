<div>
    <h3>Fill the form, and our sales team will get in touch with you shortly.</h3>
    <form wire:submit="submit" class="home_screen_form">
        <div class="mb-3">
            <label for="name" class="form-label">Full Name</label>
            <input wire:model="name" name="name" type="name" class="form-control" id="name">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="display: block;position: relative;color: red;margin-top: -15px;font-size: 11px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input wire:model="email" name="email" type="email" class="form-control" id="email">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="display: block;position: relative;color: red;margin-top: -15px;font-size: 11px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">Phone</label>
            <input wire:model="phone" name="phone" type="phone" class="form-control" id="phone">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="display: block;position: relative;color: red;margin-top: -15px;font-size: 11px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="mb-3">
            <label for="message" class="form-label">Message</label>
            <textarea wire:model="message" name="message" class="form-control" id="message" rows="3"></textarea>
        </div>
        <div class="mb-3">
            <button type="submit" class="btn btn-primary mb-3">Submit</button>
        </div>
    </form>

    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div><?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/components/contact-form.blade.php ENDPATH**/ ?>