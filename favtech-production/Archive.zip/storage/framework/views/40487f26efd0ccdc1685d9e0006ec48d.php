<?php

    function signOut() {
        echo 'Hello Absi';
    }
 ?><?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/components/layouts/temp.blade.php ENDPATH**/ ?>