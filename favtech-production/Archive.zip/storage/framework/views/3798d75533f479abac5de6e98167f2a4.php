<div>
    
    <h3>Signup</h3>
</div>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/livewire/signup-page.blade.php ENDPATH**/ ?>