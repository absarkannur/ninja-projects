<div>
    @filament('about')
    Comming Soon
</div><?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/livewire/dash-about-page.blade.php ENDPATH**/ ?>