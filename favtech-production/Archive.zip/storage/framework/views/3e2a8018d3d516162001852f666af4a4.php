<div
    <?php echo e($attributes->class([
            'fi-btn-group grid grid-flow-col rounded-lg shadow-sm ring-1 ring-gray-950/10 dark:ring-white/20',
        ])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/vendor/filament/support/src/../resources/views/components/button/group.blade.php ENDPATH**/ ?>