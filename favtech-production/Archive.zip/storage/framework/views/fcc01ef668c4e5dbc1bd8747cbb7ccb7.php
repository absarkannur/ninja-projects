
<?php if( session('user') ): ?>
    <ul class="top-nav">
        <li style="cursor: initial;"><?php echo e(session('user')->name); ?></li>
        <li><a href=<?php echo e(route('signout')); ?>>Sign Out</a></li>
    </ul>
<?php else: ?>
    <ul class="top-nav">
        <li><a href=<?php echo e(route('register')); ?>>Register</a></li>
        <li><a href=<?php echo e(route('signin')); ?>>Sign In</a></li>
    </ul>
<?php endif; ?><?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/components/top-nav.blade.php ENDPATH**/ ?>