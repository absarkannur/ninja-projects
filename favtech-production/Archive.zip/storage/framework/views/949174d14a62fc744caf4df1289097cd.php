<div class="price-list-wrapper">
    
    <div class="inner-header-wrapper" style="<?php echo e('background-image: url(' .asset( 'fav/images/inner-banner.png' ) . ')'); ?>">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <h1>Price List</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="inner-content-wrapper gap">
        <div class="container">
            
            <div class="row">
                <div class="col-12">
                    <h5>Latest Price List</h5>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <ul class="price-list">
                        <!--[if BLOCK]><![endif]--><?php if( $price_list ): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $price_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a target="__blank" href=<?php echo e(asset( 'storage/' . $price['price_list'] )); ?>>
                                    <li class="list">
                                        <span class="title">
                                            <?php echo e($price['price_list']); ?>

                                            <span class="date"><?php echo e($price['created_at']); ?></span>
                                        </span>
                                        <svg width="20" height="20">
                                            <use xlink:href=<?php echo e(asset('fav/images/svg-sprint.svg#download-thick-shape')); ?>></use>
                                        </svg>
                                    </li>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
            </div>
        </div>
    </div>


</div>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/favtech/resources/views/livewire/price-list-page.blade.php ENDPATH**/ ?>