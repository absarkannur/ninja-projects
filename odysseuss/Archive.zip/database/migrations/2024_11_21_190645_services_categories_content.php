<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('services_categories_contect', function (Blueprint $table) {
            $table->id();
            $table->foreignId('services_categories_id')->constrained()->cascadeOnDelete();
            $table->string('service_category_contect_image');
            $table->longText('service_category_contect_description');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
