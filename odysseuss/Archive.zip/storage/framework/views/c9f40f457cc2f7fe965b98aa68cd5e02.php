<section class="container">
    <div class="letsconnect-wrapper">
        <span class="heading">Ready for Data-Driven Growth?</span>
        <a href="<?php echo e(route('contact-us')); ?>" class="btn odys-black-btn">
            Let's Connect&nbsp;
            <img src=<?php echo e(asset('odys_assets/images/icons/btn-arrow-white.svg')); ?> alt="">
        </a>
    </div>
</section>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/odysseuss/resources/views/components/inc/connect.blade.php ENDPATH**/ ?>