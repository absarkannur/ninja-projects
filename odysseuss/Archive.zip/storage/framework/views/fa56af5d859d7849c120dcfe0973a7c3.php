<main class="service-inner-wrapper">

    <section class="container-fluid innerpage-banner" style="background-image: url(<?php echo e(asset( 'storage/' . $service['service_short_image'] )); ?>)">
        <div class="container">
            <h1 class="heading-inner"><?php echo e($service['service_list_header']); ?></h1>
        </div>
    </section>

    <section class="container-fluid content-wrapper">
        <div class="container">

            <div class="row">
                <div class="col">
                    <?php echo $service['service_inner_page']; ?>

                </div>
            </div>
        </div>
    </section>

    <!--[if BLOCK]><![endif]--><?php if($service_list): ?>
        <ul class="service_list">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $service_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list">
                <div class="container">
                    <h4><?php echo e($service['service_category_name']); ?></h4>
                    <ul class="contents-list">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $service['service_contents']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="content">
                            <div class="wrap">
                                <div class="image-wrap">
                                    <div class="imagethmb">
                                        <div class="imagethmb_inner">
                                            <img src=<?php echo e(asset( 'storage/'. $content['service_category_contect_image'] )); ?> alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="content-wrap">
                                    <?php echo $content['service_category_contect_description']; ?>

                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</main>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/odysseuss/resources/views/livewire/service-page.blade.php ENDPATH**/ ?>