<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="<?php echo e($header_data->description); ?>"/>
        <meta name="keywords" content="<?php echo e(implode(',', $header_data->keywords )); ?>">

        <title><?php echo e($title ?? 'Odysseus Strategies'); ?></title>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href=<?php echo e(asset( 'odys_assets/css/bootstrap.min.css' )); ?>>

        <link rel="stylesheet" href=<?php echo e(asset( 'odys_assets/css/animate.min.css' )); ?>>
        <link rel="stylesheet" href=<?php echo e(asset( 'odys_assets/css/init.css' )); ?>>
        <link rel="stylesheet" href=<?php echo e(asset( 'odys_assets/css/styles.css' )); ?>>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


        <?php echo $header_data->scripts; ?>


    </head>
    <body>

        
        <?php if (isset($component)) { $__componentOriginal31957d141ae861b1f5561ff93907165b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal31957d141ae861b1f5561ff93907165b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal31957d141ae861b1f5561ff93907165b)): ?>
<?php $attributes = $__attributesOriginal31957d141ae861b1f5561ff93907165b; ?>
<?php unset($__attributesOriginal31957d141ae861b1f5561ff93907165b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31957d141ae861b1f5561ff93907165b)): ?>
<?php $component = $__componentOriginal31957d141ae861b1f5561ff93907165b; ?>
<?php unset($__componentOriginal31957d141ae861b1f5561ff93907165b); ?>
<?php endif; ?>

        <?php echo e($slot); ?>


        <?php if (isset($component)) { $__componentOriginaldecdf1560f53ea98c37561ca77a1cd91 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldecdf1560f53ea98c37561ca77a1cd91 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inc.connect','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inc.connect'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldecdf1560f53ea98c37561ca77a1cd91)): ?>
<?php $attributes = $__attributesOriginaldecdf1560f53ea98c37561ca77a1cd91; ?>
<?php unset($__attributesOriginaldecdf1560f53ea98c37561ca77a1cd91); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldecdf1560f53ea98c37561ca77a1cd91)): ?>
<?php $component = $__componentOriginaldecdf1560f53ea98c37561ca77a1cd91; ?>
<?php unset($__componentOriginaldecdf1560f53ea98c37561ca77a1cd91); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalf616a8f3c572fc16e4336d6c64a747a8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf616a8f3c572fc16e4336d6c64a747a8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf616a8f3c572fc16e4336d6c64a747a8)): ?>
<?php $attributes = $__attributesOriginalf616a8f3c572fc16e4336d6c64a747a8; ?>
<?php unset($__attributesOriginalf616a8f3c572fc16e4336d6c64a747a8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf616a8f3c572fc16e4336d6c64a747a8)): ?>
<?php $component = $__componentOriginalf616a8f3c572fc16e4336d6c64a747a8; ?>
<?php unset($__componentOriginalf616a8f3c572fc16e4336d6c64a747a8); ?>
<?php endif; ?>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/ScrollMagic.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/plugins/animation.gsap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/plugins/debug.addIndicators.min.js"></script>

        <script src=<?php echo e(asset( 'odys_assets/js/jquery.min.js' )); ?>></script>
        <script src=<?php echo e(asset( 'odys_assets/js/parallax.min.js' )); ?>></script>
        <script src=<?php echo e(asset( 'odys_assets/js/bootstrap.bundle.min.js' )); ?>></script>
        <script src=<?php echo e(asset( 'odys_assets/js/script.js' )); ?>></script>

        <script>
            // Banner Image View
            $('.banner-wrapper').parallax({imageSrc:  "<?php echo e(asset('odys_assets/images/banner.png')); ?>" });
        </script>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    </body>
</html>
<?php /**PATH /Users/muhammedabsar/Documents/ninja-projects/odysseuss/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>