<section class="topbar-wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <p class="text">Why do we use the Odysseuss as our symbol?
                    <a href="" class="link">Discover the idea behind</a>
                </p>
            </div>
        </div>
    </div>
</section>
