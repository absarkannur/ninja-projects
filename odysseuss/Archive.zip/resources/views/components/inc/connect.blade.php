<section class="container">
    <div class="letsconnect-wrapper">
        <span class="heading">Ready for Data-Driven Growth?</span>
        <a href="{{ route('contact-us') }}" class="btn odys-black-btn">
            Let's Connect&nbsp;
            <img src={{ asset('odys_assets/images/icons/btn-arrow-white.svg') }} alt="">
        </a>
    </div>
</section>
