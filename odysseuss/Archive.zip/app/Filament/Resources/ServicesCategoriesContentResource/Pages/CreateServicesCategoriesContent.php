<?php

namespace App\Filament\Resources\ServicesCategoriesContentResource\Pages;

use App\Filament\Resources\ServicesCategoriesContentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateServicesCategoriesContent extends CreateRecord
{
    protected static string $resource = ServicesCategoriesContentResource::class;
}
